
package store.management.system;




public class StoreManagementSystem {

   
    public static void main(String[] args) {
     
        
        Helper.displayMenu();
       
    }
}
